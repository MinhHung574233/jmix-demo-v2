import {applyTheme as _applyTheme} from './theme-frontend-app.generated.js';
export const applyTheme = _applyTheme;
