import {applyTheme as _applyTheme} from './theme-backend-app.generated.js';
export const applyTheme = _applyTheme;
