// CAUTION: copied from @vaadin/tabsheet/theme/material/vaadin-tabsheet.js [last update Vaadin 24.4.4]
import '@vaadin/tabs/theme/material/vaadin-tabs.js';
import '@vaadin/scroller/theme/material/vaadin-scroller.js';
import './jmix-tabsheet-styles.js';
import '../../../src/tabsheet/jmix-tabsheet.js';
